import {FaBars} from "react-icons/fa";
import {IconContext} from "react-icons/lib";
import {
  MobileIcon,
  Nav,
  NavbarContainer,
  NavBtn,
  NavBtnLink,
  NavItem,
  NavLogo,
  NavMenu,
} from "./NavbarElements";
import {NavLink} from "react-router-dom";

const Navbar = ({toggle}) => {
  return (
    <>
      <IconContext.Provider value={{color: "#fff"}}>
        <Nav>
          <NavbarContainer>
            <NavLogo to="/">Albumify</NavLogo>
            <MobileIcon onClick={toggle}>
              <FaBars />
            </MobileIcon>
            <NavMenu>
              <NavItem>
                <NavLink to="/top-albums-main" style={{color: "white"}}>
                  Top 500 Albums
                </NavLink>
              </NavItem>
              <NavItem>
                <NavLink to="/stats" style={{color: "white"}}>
                  Cool Stats
                </NavLink>
              </NavItem>
              <NavItem>
                <NavLink to="/register" style={{color: "white"}}>
                  Register
                </NavLink>
              </NavItem>
              {/* <NavItem>
                <NavLink to="extrathing" style={{color: "white"}}>Extra Thing</NavLink>
              </NavItem> */}
            </NavMenu>
            <NavBtn>
              <NavBtnLink to="/signin">Sign In</NavBtnLink>
            </NavBtn>
          </NavbarContainer>
        </Nav>
      </IconContext.Provider>
    </>
  );
};

export default Navbar;
