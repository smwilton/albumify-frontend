import styled from'styled-components'

export const AlbumsContainer = styled.section`

/* display:grid; */
`

