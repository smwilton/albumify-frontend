
import { AlbumsContainer } from './AlbumsElements'

import TopCards from '../TopCards'

const Albums = ({ albums }) => {
  return (
    <AlbumsContainer>
   
  
   

{albums.map((album, index) => (
      <TopCards
        key={index}
        album={album}
      
      />
    ))}
   
    </AlbumsContainer>
  )
}

export default Albums