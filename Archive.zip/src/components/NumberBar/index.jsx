import React from "react";
import {NumberBarItem, NumberBarContainer, NumberBarLink} from './NumberBarElements' 

const NumberBar = () => {
  return (
    <NumberBarContainer>
      <NumberBarItem>
      <NumberBarLink to='/'>500-401</NumberBarLink > 
      </NumberBarItem>
      <NumberBarItem>
      <NumberBarLink to='/'>400-301</NumberBarLink> 
      </NumberBarItem>
      <NumberBarItem>
      <NumberBarLink to='/'>300-201</NumberBarLink> 
      </NumberBarItem>
      <NumberBarItem>
      <NumberBarLink to='/'>200-101</NumberBarLink> 
      </NumberBarItem>
      <NumberBarItem>
      <NumberBarLink to='/'>100-1</NumberBarLink> 
      </NumberBarItem>
    </NumberBarContainer>
  );
};

export default NumberBar;
