import styled from "styled-components";
import { Link as LinkR } from "react-router-dom";

export const NumberBarContainer = styled.div`
background-color: #3993b4;
display: flex;
  justify-content: center;
  align-items: center;
  margin-top:80px;

`
export const NumberBarItem = styled.li`
text-decoration: none;
height: 80px;
`

export const NumberBarLink = styled(LinkR)`
/* background-color: #9B3675; */
color: white;
font-size: 30px;
text-decoration: none;
  padding: 0 1rem;
  height: 100%;
  cursor: pointer;
  &:hover {
    border-bottom: 8px solid #9B3675;
    color: #9B3675;
`