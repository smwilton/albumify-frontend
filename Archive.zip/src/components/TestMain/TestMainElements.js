import styled from 'styled-components'

export const CardContainer = styled.div`
display: inline-flex;
margin-top:40px;
background:#3993b4;
align-items: center;

`
export const ImageWrap = styled.div`

&:hover {
    transition: all 0.5s ease-in-out;
    opacity:0.5;
    transform: scale(0.95);
    
  }
`

export const CardWrap = styled.div`

/* @media screen and (max-width: 250px){


} */
`