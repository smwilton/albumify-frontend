import Card from "react-bootstrap/Card";
import CardGroup from "react-bootstrap/CardGroup";
import Image1 from "/Users/sandrawilton/Desktop/WebDev/finalproject/greatest-albums/src/images/top500pink.jpg";
import Image2 from "/Users/sandrawilton/Desktop/WebDev/finalproject/greatest-albums/src/images/coolstatspink.jpg";
import Image3 from "/Users/sandrawilton/Desktop/WebDev/finalproject/greatest-albums/src/images/mypagepink.jpg";
import {Link} from "react-router-dom";
import {CardContainer, ImageWrap, CardWrap} from "./TestMainElements";

const TestMain = ({toggle}) => {
  return (
    <>
      <CardContainer>
        <CardGroup style={{background: "#3993b4", display: "inline-flex"}}>
          <Link to="/top-albums-main">
            <CardWrap >
            <Card
              style={{background: "#3993b4", color: "#fff" , maxWidth: "426px" }}>
              <ImageWrap>
                <Card.Img variant="top" src={Image1} />
              </ImageWrap>
              <Card.Body>
                <Card.Title style={{textAlign: "center"}}>
                  Top 500 Albums
                </Card.Title>
                <Card.Text style={{minHeight: "100px", textAlign: "center"}}>
                  Click here to discover the greatest 500 albums of all time!
                </Card.Text>
              </Card.Body>
            </Card>
            </CardWrap>
          </Link>

          <Link to="/stats">
            <Card
              style={{background: "#3993b4", color: "#fff", maxWidth: "426px"}}>
              <ImageWrap>
                <Card.Img variant="top" src={Image2} />
              </ImageWrap>
              <Card.Body>
                <Card.Title style={{textAlign: "center"}}>
                  Cool Stats
                </Card.Title>
                <Card.Text style={{minHeight: "100px", textAlign: "center"}}>
                  Check out our amazing album statistics compiled by you!
                </Card.Text>
              </Card.Body>
            </Card>
          </Link>

          <Link to="/my-page">
            <Card
              style={{background: "#3993b4", color: "#fff", maxWidth: "426px"}}>
              <ImageWrap>
                <Card.Img variant="top" src={Image3} />
              </ImageWrap>
              <Card.Body>
                <Card.Title style={{textAlign: "center", textAlign: "center"}}>
                  My Page
                </Card.Title>
                <Card.Text style={{minHeight: "100px", textAlign: "center"}}>
                  Come in to see your personal page!
                </Card.Text>
              </Card.Body>
            </Card>
          </Link>
        </CardGroup>
      </CardContainer>
    </>
  );
};

export default TestMain;
