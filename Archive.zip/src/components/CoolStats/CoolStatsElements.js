import styled from "styled-components";

export const CoolStatsContainer = styled.div`

`
