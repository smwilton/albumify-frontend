import Helmet from 'react-helmet'
import Navbar from '../Navbar'
import Footer from '../Footer'
import { CoolStatsContainer } from './CoolStatsElements'
const CoolStats = () => {
  return (
  <>
   <Helmet>
        <title>Cool Stats</title>
      </Helmet>
      <Navbar />
      <CoolStatsContainer>
        lorem ipsum dolor sit amet, consectetur adip
        lorem300 et ante. Cum sociis natoque penatibus et
      </CoolStatsContainer>
      <Footer />
  </>
  )
}

export default CoolStats