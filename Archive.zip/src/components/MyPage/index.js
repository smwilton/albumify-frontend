import {useEffect, useState} from "react";
import {useParams} from "react-router-dom";
import Albums from "../Albums";
import Helmet from "react-helmet";
import Navbar from "../Navbar";
import Footer from "../Footer";
import {
  MyPageContainer,
  MyPageTitle,
  GridSection,
  FavouritesColumn,
  WantedColumn,
  OwnedColumn,
  TitleText,
  AlbumsWrap,
 
} from "./MyPageElements";
import MyPageAlbum from "../MyPageAlbum"
import {RiStarSmileFill} from "react-icons/ri";
import {BsFillEmojiHeartEyesFill} from "react-icons/bs";
import {MdOutlineLibraryAddCheck} from "react-icons/md";
const MyPage = () => {
  const {id} = useParams();

  const [albums, setAlbums] = useState([]);
  var show = false;

  useEffect(() => {
    const getAlbums = async () => {
      const albumsFromServer = await fetchAlbums();
      setAlbums(albumsFromServer);
      show = true;
    };

    getAlbums();
  }, []);

  const fetchAlbums = async () => {
    const res = await fetch(`http://localhost/api/album/${id}`);
    const data = await res.json();
   
    return data;
  };

  return (
    <>
      {/* Add user's name instead of My */}
      <Helmet>
        <title>My Page</title>
      </Helmet>
      <MyPageContainer>
        <Navbar />
        <MyPageTitle>Sandra's Page</MyPageTitle>
        <GridSection>
          <FavouritesColumn>
            <TitleText>
              Favourites&#160;
              <BsFillEmojiHeartEyesFill />
            </TitleText>
            <AlbumsWrap>
          {albums.length > 0 ? <Albums albums={albums} /> : "No Albums on your Favourite List"}
          <MyPageAlbum></MyPageAlbum>
        </AlbumsWrap>
          </FavouritesColumn>
          <WantedColumn>
            <TitleText>
              Wanted&#160;
              <RiStarSmileFill />
            </TitleText>
            <AlbumsWrap>
          {albums.length > 0 ? <Albums albums={albums} /> : "No Albums on your Wanted List"}
        </AlbumsWrap>
          </WantedColumn>
          <OwnedColumn>
            <TitleText>
              Owned&#160;
              <MdOutlineLibraryAddCheck />
            </TitleText>
            <AlbumsWrap>
          {albums.length > 0 ? <Albums albums={albums} /> : "No Albums on your Owned List"}
        </AlbumsWrap>
          </OwnedColumn>
        </GridSection>
        <Footer />
      </MyPageContainer>
    </>
  );
};

export default MyPage;
