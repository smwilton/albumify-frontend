import {
  SearchBarContainer,
  SearchBarForm,
  SearchBarFormInput,
  SearchList,
  SearchBy,
  ButtonSearch,
  ButtonSearchText,
 

} from "./SearchBarElements";
import {BsSearch} from "react-icons/bs";


const SearchBar = () => {
  return (
    <SearchBarContainer>
     <SearchBarForm > 
      <SearchBarForm> 
       <SearchBarFormInput type="search" required placeholder="Search Artists, Albums" /> 
       
        <SearchList>
          <SearchBy>More Filters</SearchBy>
          {/* <SearchBy>Album</SearchBy>
          <SearchBy>Year</SearchBy>
          <SearchBy>Genre</SearchBy>
          <SearchBy>Subgenre</SearchBy> */}
        </SearchList>
        <ButtonSearch>
        <ButtonSearchText>Search</ButtonSearchText>
        </ButtonSearch>
       </SearchBarForm> 
    
     </SearchBarForm>
     
    </SearchBarContainer>
   
  );
};

export default SearchBar;
