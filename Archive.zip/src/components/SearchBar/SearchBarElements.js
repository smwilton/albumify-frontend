import styled from "styled-components";

export const SearchBarContainer = styled.div`
  height: 100px;
  background-color: #3993b4;
  justify-content: center;
  display: flex;
`;

export const SearchBarForm = styled.label`
border-radius:10px;

`;

export const SearchBarFormInput = styled.input`
  width: 500px;
  height: 55px;
  margin-top: 5px;
  position: relative;
  padding-left:15px;
  background:#fff;
  border: 1px solid #ccc;
  /* border-radius: 10px 0 0 10px; */
`;
export const SearchList = styled.select`
  width: 150px;
  height: 55px;
  font-size: 1rem;
  background-color: #fff;
  border: 1px solid #3993b4;
  border-left-color: #ccc;
  border-right-color: #ccc;
  padding-left: 6px;
  padding-right: 22px;
  border: 1px solid #ccc;
`;
export const SearchBy = styled.option`
  font-weight: normal;
  display: block;
  white-space: nowrap;
  min-height: 1.2em;
  padding: 0px 2px 1px;
  height: 55px;
  width: 350px;
  border: 1px solid #ccc;
 background-color: #fff;

`;
export const ButtonSearch = styled.button`
  width: 75px;
  /* height: 25px; */
  border-radius: 0;
  font-size: 1rem;
  background-color: #fff;
  border: 1px solid #ccc;
  border-left-color: #ccc;
  position: absolute;
  margin-top: 5px;
  height: 55px;
  /* border-radius: 0 10px 10px 0; */
`;

export const ButtonSearchText = styled.text`
background-color: #fff;
`