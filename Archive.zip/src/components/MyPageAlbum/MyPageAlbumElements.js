import styled from 'styled-components'



export const AlbumBox = styled.div`

`
export const AlbumNumber = styled.p`

`
export const AlbumName = styled.p`

`
export const ArtistName = styled.p`

`

