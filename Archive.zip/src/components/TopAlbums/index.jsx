import {useEffect, useState} from "react";
import {useSearchParams} from "react-router-dom";
import {Helmet} from "react-helmet";
import {TopAlbumsContainer, AlbumsWrap} from "./TopAlbumsElements";
import Navbar from "../Navbar";
import Footer from "../Footer";
import Albums from "../Albums";

const TopAlbums = () => {
  
  const [albums, setAlbums] = useState([]);
  const [searchParams] = useSearchParams();

  useEffect(() => {
    const getAlbums = async () => {
      const albumsFromServer = await fetchAlbums();
      setAlbums(albumsFromServer);
    };

    getAlbums();
  }, []);

  // Fetch Albums
  const fetchAlbums = async () => {
    const from = searchParams.get("from");
    const to = searchParams.get("to");
    const res = await fetch(`http://localhost/api/album?from=${from}&to=${to}`);
    const data = await res.json();

    return data;
  };

  return (
    <>
      <Helmet>
        <title>Top Albums</title>
      </Helmet>
      <TopAlbumsContainer>
        <Navbar />

        <AlbumsWrap>
          {albums.length > 0 ? <Albums albums={albums} /> : "No Albums To Show"}
        </AlbumsWrap>

        <Footer />
      </TopAlbumsContainer>
    </>
  );
};

export default TopAlbums;
