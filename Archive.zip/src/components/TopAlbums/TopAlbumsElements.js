import styled from 'styled-components'




export const Text = styled.div`
color: white;
grid-column: 2;
padding:10px;
margin-left:5px;
`

export const TopAlbumsContainer =styled.div`
background-color:#3993b4;


`

//  AlbumsWrap, AlbumsRow,Column1, AlbumBox, ImageWrap, Img
export const AlbumsWrap = styled.div`
width: 100%;
height:100%;
  

`
export const AlbumsRow = styled.div`
 display: grid;
  align-items: center;
  width: 100%;
`
export const Column1 = styled.div`
margin-bottom: 15px;
  padding: 0 15px;
  width:100%;
  grid-column: 1;
  
`
export const Column2 = styled.div`
margin-bottom: 15px;
  padding: 0 15px;
  width:100%;
  grid-column: 2;
`
export const AlbumBox = styled.div`
 margin-bottom: 15px;
 display: grid;
  padding: 0 15px;
  border: 1px solid white;
  padding: 15px;
  width:100%;
`
export const ImageWrap = styled.div`
  max-width: 555px;
  height: 100%;
  grid-column: 1;
`
export const Img = styled.img`
width: 160px;
  margin: 0 0 10px 0;
  padding-right: 0;
  
  
`