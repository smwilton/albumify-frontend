import { Card, CardImage, Title, Artist, CardContainer, Number, IconButtons, Favourite, Owned, Wanted } from "./TopCardsElements";
import Image1 from "../../images/cover2.jpeg";
import { Link } from "react-router-dom";
import {RiStarSmileFill} from "react-icons/ri";
import {BsFillEmojiHeartEyesFill} from "react-icons/bs";
import {MdOutlineLibraryAddCheck} from "react-icons/md";
import { useState } from "react"

const TopCards = ({album}) => {

  

    const linkTo = "/album-info/" + album.album_id;
    const [clsFav, setClsFav] = useState("white");
    const [clsWan, setClsWan] = useState("white");
    const [clsOwn, setClsOwn] = useState("white");
    const image = `${album.album_id}.jpg`;

  return (
    <>
    <style>{`
        .pink {color: #9B3675}
        .white {color: white}
      `}</style>
      
    <CardContainer>
   
      <Card>
      <Link to = {linkTo}>
      <Number>{album.album_number}</Number>
        <CardImage src={require(`../../images/covers/${image}`)}/>
        <Title>{album.album_name}</Title>
        <Artist>{album.artist_name}</Artist>
        </Link>
        <IconButtons >
            <Favourite title="Favourite"  className={clsFav}  onClick={() => setClsFav((clsFav) => (clsFav === "pink" ? "white" : "pink"))}><BsFillEmojiHeartEyesFill/></Favourite>
            <Wanted title="Wanted" className={clsWan}  onClick={() => setClsWan((clsWan) => (clsWan === "pink" ? "white" : "pink"))} ><RiStarSmileFill/></Wanted>
            <Owned title="Owned" className={clsOwn}  onClick={() => setClsOwn((clsOwn) => (clsOwn === "pink" ? "white" : "pink"))}  ><MdOutlineLibraryAddCheck/></Owned>
        </IconButtons>
      </Card>
      
      </CardContainer>
    </>
  );
};

export default TopCards;
