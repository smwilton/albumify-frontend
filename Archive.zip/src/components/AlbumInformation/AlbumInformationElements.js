import styled from "styled-components";


export const PageContainer = styled.div`
background:#3993b4;
`

export const AlbumInformationContainer = styled.div`
  color: #fff;
  background:#3993b4;
`;

export const TopRow = styled.div`
  display: grid;
  grid-template-columns: 1fr 2fr;
  margin: 20px;
  margin-top: 30px;
  @media screen and (max-width: 700px) {
    display: block;
  }
`;
export const BottomRow = styled.div`
  display: grid;
  grid-template-columns: 1fr 2fr;
  margin: 20px;
  @media screen and (max-width: 700px) {
    display: block;
  }
`;

export const ImageContainer = styled.div`
  margin-top: 30px;
  margin-left: 30px;
`;

export const Image = styled.img`
  width: 100%;
  height: 100%;
`;

export const MainDetails = styled.div`
  margin-left: 150px;
`;
export const AlbumNumber = styled.p`
  font-family: "Roboto Serif", sans-serif;
  font-size: 100px;

  @media screen and (max-width: 700px) {
    font-size: 40px;
    margin-top: 20px;
  }
`;
export const AlbumName = styled.h2`
  @media screen and (max-width: 700px) {
    font-size: 20px;
  }
`;
export const AlbumArtist = styled.p`
  @media screen and (max-width: 700px) {
    font-size: 20px;
  }
`;
export const AlbumYear = styled.p``;
export const AlbumRating = styled.p``;
export const AlbumRatingsCount = styled.p``;

export const AlbumGenre = styled.p``;
export const AlbumSubgenre = styled.p``;

export const LeftGrid = styled.div`
  margin-right: 100px;
  margin-left: 30px;
`;
export const RightGrid = styled.div`
  margin-left: 100px;
`;
export const ArrowRow = styled.div`
display: grid;
grid-template-columns: auto auto;

`
export const ArrowLeft = styled.div`
display: grid;

margin-left:50px;
`
export const ArrowRight = styled.div`
display: grid;

margin-right:50px;
justify-content:right;
`