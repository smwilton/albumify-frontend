import {useParams} from "react-router-dom";
import {useEffect, useState} from "react";
import {Helmet} from "react-helmet";
import Navbar from "../Navbar";
import Footer from "../Footer";
import {
  AlbumInformationContainer,
  AlbumRating,
  AlbumName,
  AlbumArtist,
  AlbumNumber,
  AlbumYear,
  AlbumRatingsCount,
  AlbumGenre,
  AlbumSubgenre,
  TopRow,
  ImageContainer,
  MainDetails,
  Image,
  BottomRow,
  LeftGrid,
  RightGrid,
  PageContainer,
  ArrowRow,
  ArrowLeft,
  ArrowRight,
} from "./AlbumInformationElements";
import {ImArrowLeft, ImArrowRight} from "react-icons/im";

const AlbumInformation = ({}) => {
  const {id} = useParams();
  const image = `${id}.jpg`;

  const [album, setAlbum] = useState([]);
  var show = false;

  useEffect(() => {
    const getAlbum = async () => {
      const albumFromServer = await fetchAlbum();
      setAlbum(albumFromServer);
      show = true;
    };

    getAlbum();
  }, []);

  const fetchAlbum = async () => {
    const res = await fetch(`http://localhost/api/album/${id}`);
    const data = await res.json();
    console.log(data.genres[0].genre_name);
    console.log(data.genres);
    return data;
  };

  return (
    <>
      <PageContainer>
        <Helmet>
          <title>Album Information</title>
        </Helmet>
        <Navbar />
        <AlbumInformationContainer>
          <TopRow>
            <ImageContainer>
              <Image src={require(`../../images/covers/${image}`)} />
            </ImageContainer>
            <MainDetails>
              <AlbumNumber>No. {album.album_number}</AlbumNumber>
              <AlbumName>{album.album_name}</AlbumName>
              <AlbumArtist>{album.artist_name}</AlbumArtist>
              <AlbumYear>Year: {album.album_year}</AlbumYear>
              <AlbumGenre>
                Album Genre(s) :{" "}
                {album != null &&
                  album?.genres?.map((genre) => genre.genre_name + " ")}
              </AlbumGenre>
              <AlbumSubgenre>
                Album Subgenre(s) :{" "}
                {album != null &&
                  album?.sub_genres?.map(
                    (sub_genre) => sub_genre.sub_genre_name + "/ "
                  )}
              </AlbumSubgenre>
              <AlbumRating>
                Average User Rating: {album.album_average_rating}&#160;(
                {album.album_ratings_count}&#160;ratings)
              </AlbumRating>
            </MainDetails>
          </TopRow>

          <BottomRow>
            <LeftGrid>
              Spotify
              <div style={{width: "400px"}}>
                <iframe
                  style={{borderRadius: "12px"}}
                  src={`https://open.spotify.com/embed/album/${album.album_spotify_id}?utm_source=generator`}
                  width="100%"
                  height="380"
                  frameBorder="0"
                  allowFullScreen=""
                  allow="autoplay; clipboard-write; encrypted-media; fullscreen; picture-in-picture"></iframe>
              </div>
            </LeftGrid>
            <RightGrid>reviews</RightGrid>
          </BottomRow>
          <ArrowRow>
            <ArrowLeft>
              <ImArrowLeft style={{fontSize: "70px"}} /> Previous Album
            </ArrowLeft>
            <ArrowRight>
              <ImArrowRight style={{fontSize: "70px"}} />
              Next Album
            </ArrowRight>
          </ArrowRow>
        </AlbumInformationContainer>

        <Footer />
      </PageContainer>
    </>
  );
};

export default AlbumInformation;
