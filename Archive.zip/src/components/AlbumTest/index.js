import {
  AlbumTestContainer,
  Album,
  AlbumNumber,
  AlbumYear,
  ArtistName,
  AlbumName,
  AlbumAverageRating,
  AlbumRatingsCount,
  MainImage,
  AlbumInfo,
} from "./AlbumTestElements";
import Navbar from "../Navbar";
import Footer from "../Footer";
import Image1 from "/Users/sandrawilton/Desktop/WebDev/finalproject/greatest-albums/src/images/vinyl-g050571fbc_1920.jpg";
const AlbumTest = ({album}) => {
  return (
    <AlbumTestContainer>
      <Album className={`album`}>
        <AlbumInfo>
        <AlbumNumber>{album.album_number}</AlbumNumber>
        <AlbumYear>{album.album_year} </AlbumYear>
        <ArtistName>{album.artist_name} </ArtistName>
        {/* <AlbumName>{album.album_name}</AlbumName> */}
        {/* <AlbumAverageRating>{album.album_average_rating}</AlbumAverageRating> */}
        {/* <AlbumRatingsCount>{album.album_ratings_count}</AlbumRatingsCount> */}
        </AlbumInfo>
      </Album>
    </AlbumTestContainer>
  );
};

export default AlbumTest;
