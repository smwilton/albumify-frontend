import styled from "styled-components";

export const AlbumTestContainer = styled.div`
 color: #fff;
  display: inline-grid;
  grid-template-columns:  auto auto auto;
 grid-template-rows: auto auto;
  grid-column-gap: 0px;
  grid-row-gap: 0px;
  max-width: 100%;
  /* height: auto; */
  background-color: #3993b4;
  
 

`
export const Album = styled.div`
/* position: relative; */
  width: 100%;
  background-color: #3993b4;
  border: 1px solid;
  padding: 20px;
  


`
export const AlbumNumber = styled.p`
color: #fff;

`
export const AlbumInfo = styled.div`
 
/* position:auto; */
`

// export const AlbumTestContainer = styled.div`
// diplay:grid;
// grid-template-columns: 1fr 2fr 2fr 2fr 1fr 1fr 1fr;
// grid-template-rows: repeat(20, 1fr); 
// grid-column-gap: 5px;
// grid-row-gap: 5px; 
// `

// export const Album = styled.div`
// border: 1px solid;
// /* color: #fff;
// display: grid; 
// grid-template-columns: 1fr 2fr 2fr 2fr 1fr 1fr 1fr;
// /* grid-template-rows: repeat(20, 1fr);  */
// /* grid-column-gap: 5px;
// grid-row-gap: 5px;  */ */

// `
// export const AlbumNumber = styled.p`
//  font-family: "Roboto Serif", sans-serif;
//   font-size: 30px;
// `
export const AlbumYear= styled.p`

`
export const ArtistName = styled.p`

`
export const AlbumName = styled.p`

`
export const AlbumAverageRating = styled.p`

`
export const AlbumRatingsCount= styled.p`

`
// export const MainImage = styled.img`
// width:200px;
// `
// //  ArtistName, AlbumName