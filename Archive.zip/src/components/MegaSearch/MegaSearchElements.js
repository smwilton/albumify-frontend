import styled from "styled-components";

export const MegaSearchContainer = styled.div`
  height: auto;
  background-color: #3993b4;
  overflow: visible;
  display: grid;
  grid-template-columns: auto auto auto;
`;
export const SearchGroup = styled.div`
  color: #fff;
  dislay: grid;
`;
export const SearchHeading = styled.p`
  text-transform: uppercase;
  size: 13.6px;
  margin-bottom: 10px;
  font-weight: bold;
  text-align: center;
`;
export const SearchByYear = styled.div`
  border: 3px solid #fff;
  display: grid;
  grid-template-columns: auto auto;
`;

export const MinYear = styled.option``;
export const MaxYear = styled.option``;

export const MinYearContainer = styled.select`
  display: grid;
`;

export const MaxYearContainer = styled.select`
  display: grid;
`;
