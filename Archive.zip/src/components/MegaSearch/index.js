import {
  MegaSearchContainer,
  SearchGroup,
  SearchHeading,
  SearchByYear,
  MinYear,
  MaxYear,
  MinYearContainer,
  MaxYearContainer,
  
} from "./MegaSearchElements";

const MegaSearch = () => {




  const createYears = () => {
    let years = [];
    for (let year = 1900; year <= 2030; year++) {
      years.push(year);
    }

    return years;
  };
  const years = createYears();

  // const [genre, setGenre] = useState([]);

  // useEffect(() => {
  //   const getGenre = async () => {
  //     const genreFromServer = await fetchGenre();
  //     setGenre(genreFromServer);
  //     show = true;
  //   };

  //   getAlbum();
  // }, []);

  // const fetchGenre  = () => {
  //    const res = await fetch(`http://localhost/api/album/${id}`);
  //   const data = await res.json();
  //   return data;
  // };
  return (
    <>
      <MegaSearchContainer>
        <SearchGroup>
          <SearchHeading>year range</SearchHeading>
          <SearchByYear>
            <MinYearContainer>
              <MinYear>From</MinYear>
              {years.map((item, index) => {
                return <MinYear key={index}>{item}</MinYear>;
              })}
            </MinYearContainer>
            <MaxYearContainer>
              <MaxYear>To</MaxYear>
              {years.map((item, index) => {
                return <MaxYear key={index}>{item}</MaxYear>;
              })}
            </MaxYearContainer>
          </SearchByYear>
        </SearchGroup>
        <SearchGroup>
          <SearchHeading>search by genre</SearchHeading>
         
        </SearchGroup>
        <SearchGroup>
          <SearchHeading>search by subgenre</SearchHeading>
        </SearchGroup>
      </MegaSearchContainer>
    </>
  );
};

export default MegaSearch;
