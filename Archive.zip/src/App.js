
import './App.css';

import Home from './pages'
import SigninPage from './pages/signin'
import TopAlbumsPage from './pages/topAlbums'
import RegisterPage from './pages/register'
import CoolStatsPage from './pages/coolStats'
import AlbumInformationPage from './pages/albumInfo'
import TopAlbumsFrontPage from './pages/topAlbumsFrontPage'
import TestMainPage from './pages/testMain'
import MyPagePage from './pages/myPage'
import AlbumTest from './components/AlbumTest'
import TopCards from './components/TopCards';
import PasswordReset from './components/PasswordReset'
import MegaSearch from './components/MegaSearch'

import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';

function App() {
  return (
    <Router style={{backgroundColor: '#3993b4'}}>
       <Routes>
     
        <Route path='/' element={<Home/>} />
        <Route path="/signin" element={<SigninPage />} />
        <Route path="/top-albums" element={<TopAlbumsPage />} />
        <Route path="/register" element={<RegisterPage />} />
        <Route path="/stats" element={<CoolStatsPage />} />
        <Route path="/album-info/:id" element={<AlbumInformationPage />} />
        <Route path="/top-albums-main" element={<TopAlbumsFrontPage />} />
        <Route path="/test-main" element={<TestMainPage />} />
        <Route path="/my-page" element={<MyPagePage />} />
        {/* <Route path="/album-test" element={<AlbumTest />} /> */}
        <Route path="/top-cards" element={<TopCards />} />
        {/* <Route path="/password-reset" element={<PasswordReset />} /> */}
        <Route path="/mega-search" element={<MegaSearch />} />
        
        


       </Routes>

      
        </Router>
  );
}

export default App;
