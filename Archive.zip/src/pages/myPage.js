import MyPage from '../components/MyPage'

const MyPagePage = () => {
  return (
    <>
      <MyPage />
    </>
  );
};

export default MyPagePage;
