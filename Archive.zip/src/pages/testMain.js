import Navbar from "../components/Navbar";
import HeroSection from "../components/HeroSection";
import TestMain from "../components/TestMain";
import Footer from "../components/Footer";

const TestMainPage = () => {
  return (
    <>
      <Navbar />
      <HeroSection />
      <TestMain />
      <Footer />
    </>
  );
};

export default TestMainPage;
