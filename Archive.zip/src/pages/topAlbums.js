
import TopAlbums from "../components/TopAlbums";

const TopAlbumsPage = () => {
  return (
    <>
  
      <TopAlbums />
    </>
  );
  }

export default TopAlbumsPage;
