import React from 'react'
import CoolStats from '../components/CoolStats'

const CoolStatsPage = () => {
    return (
        <>
          <CoolStats />
        </>
    )
}

export default CoolStatsPage
