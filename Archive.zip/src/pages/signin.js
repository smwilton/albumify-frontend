import SignIn from '../components/SignIn'

import React from 'react'

const SigninPage = () => {
    return (
        <>
          <SignIn />  
        </>
    )
}

export default SigninPage
