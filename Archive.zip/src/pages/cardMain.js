import CardMain from "../components/CardMain"

const CardMainPage = () => {
  return (
    <><CardMain /></>
  )
}

export default CardMainPage